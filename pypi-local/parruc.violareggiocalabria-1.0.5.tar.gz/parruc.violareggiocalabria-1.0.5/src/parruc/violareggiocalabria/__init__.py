# -*- coding: utf-8 -*-
"""Init and utils."""

from zope.i18nmessageid import MessageFactory

import monkey


_ = MessageFactory('parruc.violareggiocalabria')

monkey  # pyflakes
