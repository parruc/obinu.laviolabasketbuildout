# -*- coding: utf-8 -*-
"""Init and utils."""

from profiling import profiled
from zope.i18nmessageid import MessageFactory


_ = MessageFactory('parruc.devtools')


profiled  # Pylint
