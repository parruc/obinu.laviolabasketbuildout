# -*- coding: utf-8 -*-
#  from plone import api
from Products.Five.browser import BrowserView


# from .. import messageFactory as _


class VideoView(BrowserView):

    pass
