====================
parruc.flexslider
====================

User documentation
