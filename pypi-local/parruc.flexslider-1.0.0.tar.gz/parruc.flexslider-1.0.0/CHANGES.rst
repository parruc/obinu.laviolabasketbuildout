Changelog
=========


1.0.0 (2016-09-18)
------------------

- Initial release.
  [parruc]
