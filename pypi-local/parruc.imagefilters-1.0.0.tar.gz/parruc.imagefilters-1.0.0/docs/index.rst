====================
parruc.imagefilters
====================

User documentation
