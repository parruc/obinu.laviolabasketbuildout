Changelog
=========


1.0.0 (2016-09-19)
------------------

- Initial release.
  [parruc]
